import java.io.*;
import java.util.*;


public class GamePlayer{
    public static int playgame_dc(GameBoard gb, int left, int right){
        // Base case
        int answer = 2;
        if (left == right){
            answer = left;
        }
        // Divide
        // Conquer
        // Combine
        return answer;
    }
}