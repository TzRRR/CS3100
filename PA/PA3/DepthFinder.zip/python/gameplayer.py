

def playgame_dc(gb, left, right):
    # Basecase
    answer = 2
    if(left == right):
        answer = left
    # Divide
    # Conquer
    # Combine
    return answer


