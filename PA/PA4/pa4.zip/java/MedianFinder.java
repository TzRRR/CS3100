
public class MedianFinder{
    
    public static double findMedian(Company c1, Company c2){
        return -1.0;
    }


}
