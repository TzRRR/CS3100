import math

def find_median(c1, c2):
    return -1
