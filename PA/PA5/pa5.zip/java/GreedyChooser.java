import java.io.*;
import java.util.*;

public class GreedyChooser{

    public static int deadlines(ArrayList<Pair> input_list){
	// input: a list of pairs or doubles (completion time, due time)
        // output: index of the assignment to complete first
        return 0;
    }

    public static int bakeoff(ArrayList<Pair> input_list){
	// input: a list of pairs or doubles (active time, passive time)
        // output: index of the component to make first
        return 0;
    }

    public static int mileage(ArrayList<Pair> input_list){
	// input: a list of pairs or doubles (mpg, miles)
        // output: index of the car to deliver first
        return 0;
    }
}
