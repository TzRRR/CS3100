
def bakeoff(input_list):
    # input: a list of pairs or floats (active time, passive time)
    # output: index of the component to make first
    return 0

def deadlines(input_list):
    # input: a list of pairs or floats (completion time, due time)
    # output: index of the assignment to complete first
    return 0

def mileage(input_list):
    # input: a list of pairs or floats (mpg, miles)
    # output: index of the car to deliver first
    return 0