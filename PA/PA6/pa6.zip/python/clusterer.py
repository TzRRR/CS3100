import heapq as pq

def cluster_cost(k, distances):
    print(0.0)