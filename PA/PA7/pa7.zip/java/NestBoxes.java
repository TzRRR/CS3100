import java.util.*;

public class NestBoxes{
    public static int max_depth(Box[] boxes){
        return 1;
    }
}
