memory = []

def max_depth(boxes):
    return 1
