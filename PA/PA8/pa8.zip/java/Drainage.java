public class Drainage{
    public static void max_run(int[][] grid){
        System.out.println("0 0");
    }
}
