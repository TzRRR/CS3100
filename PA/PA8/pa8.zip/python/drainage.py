def max_run(grid):
    print(0,0)
